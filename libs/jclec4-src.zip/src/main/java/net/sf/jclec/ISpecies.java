package net.sf.jclec;

/**
 * Individual species.
 * 
 * @author Sebastian Ventura
 */

public interface ISpecies extends JCLEC
{
}
