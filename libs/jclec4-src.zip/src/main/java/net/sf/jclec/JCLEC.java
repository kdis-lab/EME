package net.sf.jclec;

import java.io.Serializable;

/**
 * Root for the JCLEC hierarchy
 * 
 * @author Sebastian Ventura
 */

public interface JCLEC extends Serializable 
{
}
